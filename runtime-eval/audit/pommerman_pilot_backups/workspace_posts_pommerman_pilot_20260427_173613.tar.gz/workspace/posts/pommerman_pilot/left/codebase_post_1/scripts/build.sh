#!/usr/bin/env bash
set -euo pipefail
echo "[build] placeholder build succeeded"
